<html>
<head>
<title>Add Student</title>
</head>

<body>

<?php
require_once('mysql_connect.php');

$query = "SELECT * FROM STUDENTS ";

$responce = mysqli_query($conn,$query);

if($responce){
echo '<table 
cellspacing="5" cellpadding="8" border="1">

<tr> <td align="left"><b>name</b></td>
<td align="left"><b>roll_no</b></td>
<td align="left"><b>branch</b></td>
<td align="left"><b>college</b></td>
<td align="left"><b>Delete</b></td>
<td align="left"><b>Edit</b></td>  
 </tr>';

 
  if($responce){
       //var_dump(mysqli_fetch_array($responce));

        while($row = mysqli_fetch_array($responce,MYSQLI_ASSOC)){
              echo "<tr>";

              echo "<td>"."$row[name]"."</td>";
              echo "<td>"."$row[roll_no]"."</td>";
              echo "<td>"."$row[branch]"."</td>";
              echo "<td>"."$row[college]"."</td>";

              //for deleting
              echo "<td>";

              echo "<form action='deleted_details.php' method='post'>";

              echo " <p>";
              echo "<input type='hidden' name='roll_no' size='10' value='$row[roll_no]' />";
              echo"</p>";

	      echo "<p>";
              echo "<input type='submit' name='submit' value='Delete'/>";
              echo "</p>";
              
              echo "</form>";

              echo "</td>";


              //for editing
              
              echo "<td>";

              echo "<form action='edit_details.php' method='post'>";

              echo " <p>";
              echo "<input type='hidden' name='roll_no' size='10' value='$row[]' />";
              echo"</p>";

	      echo "<p>";
              echo "<input type='submit' name='submit' value='Edit'/>";
              echo "</p>";
              
              echo "</form>";

              echo "</td>";
   	      echo "</tr>";

              


           }

echo "</table>";


      
        
  }



}
else{

echo "query failed";
}



?>




<form action="add_details.php" method="post">

<b>Add a New Student</b>
<p>
<input type="submit" name="submit" value="Add" />
</p>

</form>










</body>

</html>














