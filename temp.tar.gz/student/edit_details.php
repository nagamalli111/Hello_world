<html>
<head>
<title>Add Student</title>
</head>

<body>

<?php

   if( $_POST ){

     


	$con = mysqli_connect("localhost","root","1");
        mysqli_select_db($con,"testDB");
  
	if(!con){
        echo "no connection";   
        }
//echo "$_POST[name]";
var_dump($_POST);


echo "$_POST[name]";
    
echo "<form action='added_details.php' method='post'>";

echo "<b>Add a New Student</b>";

echo "<p>Name:";
echo "<input type='varchar' name='name' size='20' value='' placeholder='$_POST[roll_no]'/>";
echo "</p>";


echo "<p>";
echo "<input type='submit' name='submit' value='Send' />";
echo "</p>";

echo "</form>";

}

else{

echo "no connection";
}




?>

</body>


</html>
