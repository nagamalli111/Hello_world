<?php


$conn = mysqli_connect("localhost","root","1","testDB");

if(!$conn){

  echo "Please try later";

}
else{

//echo "connection established";
}

?>
