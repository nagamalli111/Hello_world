
<html>
<head>
<title>Delete Student</title>
</head>

<body>
<?php

   if( $_POST ){


	$con = mysqli_connect("localhost","root","1");
        mysqli_select_db($con,"testDB");
  
	if(!con){
        echo "no connection";   
        }
        


        $com = "DELETE FROM `STUDENTS` WHERE roll_no = $_POST[roll_no]";
      }


    // echo "$com";



    $ok =  mysqli_query($con,$com);
 
   if(!$ok){

    echo "not";
  }

  else{

  echo "successfully deleted the information";

 

    }






?>

<form action="get_student_details.php" method="post">

<p>
<input type="submit" name="submit" value="Back" />
</p>

</form>




</body>

</html>





