<html>
<head>
<title> Student Details</title>
</head>
<body>

<h1> this is index.php</h1>



</body>

</html>
