<html>
<head>
<title> Student Details</title>
</head>
<body>
<form action="get_student_details.php" method="post">

<p> Display all students Details</p>
<p>
<input type="submit" name="submit" value="Display" />
</p>

</form>


<form action="add_details.php" method="post">

<p> Add the student details </p>
<p>
<input type="submit" name="submit" value="add" />
</p>

</form>


<form action="delete_details.php" method="post">

<p> Delete the student Details by roll number</p>
<p>
<input type="submit" name="submit" value="delete" />
</p>

</form>
</body>

</html>
