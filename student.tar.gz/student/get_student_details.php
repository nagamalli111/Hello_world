<html>
<head>
<title>Add Student</title>
</head>

<body>

<?php
require_once('mysql_connect.php');

$query = "SELECT * FROM STUDENTS ";

$responce = mysqli_query($conn,$query);

if($responce){
echo '<table align="left"
cellspacing="5" cellpadding="8" border="1">

<tr> <td align="left"><b>name</b></td>
<td align="left"><b>roll_no</b></td>
<td align="left"><b>branch</b></td>
<td align="left"><b>college</b></td> </tr>';

 
  if($responce){
       //var_dump(mysqli_fetch_array($responce));

        while($row = mysqli_fetch_array($responce,MYSQLI_ASSOC)){
              echo "<tr>";

              echo "<td>"."$row[name]"."</td>";
              echo "<td>"."$row[roll_no]"."</td>";
              echo "<td>"."$row[branch]"."</td>";
              echo "<td>"."$row[college]"."</td>";

   	      echo "</tr>";


           }

echo "</table>";
      
        
  }



}
else{

echo "query failed";
}



?>

<form action="index.php" method="post" align = "left">


<p>
<input type="submit" name="submit" value="Back" />
</p>

</form>




</body>

</html>














