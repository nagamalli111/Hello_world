<html>
<head>
<title>Delete Student</title>
</head>

<body>

<form action="deleted_details.php" method="post">

<b>Delete a New Student</b>

<p> Enter a Roll Number to Delete </p>
<p>Roll Number:
<input type="int" name="roll_no" size="10" value="" />
</p>


<p>
<input type="submit" name="submit" value="Send" />
</p>

</form>




</body>

</html>
