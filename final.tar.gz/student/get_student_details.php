<html>
<head>
<title>Add Student</title>

 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


</head>

<body>
<div class = "container">

   <h1 align = "center" > Student Details </h1>

   <br>

<?php
require_once('mysql_connect.php');

$query = "SELECT * FROM STUDENTS ";

$responce = mysqli_query($conn,$query);

if($responce){
echo '<table   class="table table-hover" >

<tr> <td align="left"><b>Name</b></td>
<td align="left"><b>Roll No</b></td>
<td align="left"><b>Branch</b></td>
<td align="left"><b>College</b></td>
<td align="left"><b>Delete</b></td>
<td align="left"><b>Edit</b></td>  
 </tr>';

 
  if($responce){
       //var_dump(mysqli_fetch_array($responce));

        while($row = mysqli_fetch_array($responce,MYSQLI_ASSOC)){
              echo "<tr>";

              echo "<td>"."$row[name]"."</td>";
              echo "<td>"."$row[roll_no]"."</td>";
              echo "<td>"."$row[branch]"."</td>";
              echo "<td>"."$row[college]"."</td>";

              //for deleting
              echo "<td>";

              echo "<form action='deleted_details.php' method='post'>";

              echo " <p>";
              echo "<input type='hidden' name='roll_no' size='10' value='$row[roll_no]' />";
              echo"</p>";

	      echo "<p>";
              echo "<input class='btn btn-warning' type='submit' name='submit' value='Delete' />";
              echo "</p>";
              
              echo "</form>";

              echo "</td>";


              //for editing


              echo "<td>";

              echo "<form action='edit_details.php' method='post'>";

              echo " <p>";
              echo "<input type='hidden' name='roll_no' size='10' value='$row[roll_no]' />";
              echo"</p>";

              echo "<p>";
              echo "<input class='btn btn-info' type='submit' name='submit' value='update'/>";
              echo "</p>";



              
              echo "</form>";

              echo "</td>";

		


 
   	      echo "</tr>";

              


           }

echo "</table>";


      
        
  }



}
else{

echo "query failed";
}



?>

<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Add student</button>


<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add student Details</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>



      <div class="modal-body">


        <form action="added_details.php" method="post">


          <div class="form-group">
            <label for="recipient-name" class="form-control-label">Name:</label>
            <input type="text" class="form-control" id="recipient-name" name ="name">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="form-control-label">Roll No:</label>
            <input type="text" class="form-control" id="recipient-name" name = "roll_no">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="form-control-label">Branch:</label>
            <input type="text" class="form-control" id="recipient-name" name = "branch">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="form-control-label">College:</label>
            <input type="text" class="form-control" id="recipient-name" name = "college">
          </div>



<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>

<input type="submit" name="submit" value="Add Student" class = "btn btn-success"/>
</div>



</form>

</div>
</div>
</div>
</div>



<div class="container" >                 
  <ul class="pagination">

    <li><a href="add_details.php">1</a></li>
    <li><a href="#">2</a></li>
    <li><a href="#">3</a></li>
    <li><a href="#">4</a></li>
    <li><a href="#">5</a></li>
  </ul>
</div>



</div>

</body>

</html>














