<html>
<head>
<title>Add Student</title>
</head>

<body>


<?php

  if( $_POST ){
  $con = mysqli_connect("localhost","root","1","testDB");
         
  
  if(!con){
        echo "no connection";   
        }

                 
        $com = "INSERT INTO `STUDENTS` (`name`, `roll_no`, `branch`, `college`) VALUES ( '$_POST[name]', '$_POST[roll_no]', '$_POST[branch]', '$_POST[college]');";
}


    // echo "$com";



    $ok =  mysqli_query($con,$com);
 
   if(!$ok){

    echo "Added data was insufficient";
  }

  else{

   header("Location:get_student_details.php");
    exit;


  echo "successfully added the information";


    }


?>

<form action="get_student_details.php" method="post">


<p>
<input type="submit" name="submit" value="Back" />
</p>

</form>




</body>

</html>






