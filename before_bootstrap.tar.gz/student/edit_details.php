
<html>
<head>
<title>Delete Student</title>
</head>

<body>
<?php
if($_POST){  

$conn = mysqli_connect("localhost","root","1","testDB");




$query = "SELECT * FROM STUDENTS WHERE roll_no = $_POST[roll_no]";

$responce = mysqli_query($conn,$query);

$com = "DELETE FROM `STUDENTS` WHERE roll_no = $_POST[roll_no]";

$dele_responce = mysqli_query($conn,$com);


if($responce){
	$row = mysqli_fetch_array($responce,MYSQLI_ASSOC);


	          echo "<form action='added_details.php' method='post'>";

              echo " <p>Name: ";
              echo "<input type='varchar' name='name' size='20' value='$row[name]' />";
              echo"</p>";
	    

              echo " <p>Roll No: ";
              echo "<input type='int' name='roll_no' size='10' value='$row[roll_no]' />";
              echo"</p>";


              echo " <p>Branch: ";
              echo "<input type='varchar' name='branch' size='15' value='$row[branch]' />";
              echo"</p>";


              echo " <p>College: ";
              echo "<input type='varchar' name='college' size='20' value='$row[college]' />";
              echo"</p>";

              echo "<p>";
              echo "<input type='submit' name='submit' value='add'/>";
              echo "</p>";

              echo "</form>";
}

else{
	
	echo "no responce";
}


}

else{
	echo "no post";
}




?>


</body>

</html>





