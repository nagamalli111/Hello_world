<html>
<head>
<title>Add Student</title>
</head>

<body>

<form action="added_details.php" method="post">

<b>Add a New Student</b>

<p>Name:
<input type="varchar" name="name" size="20" value="" />
</p>

<p>Roll Number:
<input type="int" name="roll_no" size="10" value="" />
</p>
<p>Branch:
<input type="varchar" name="branch" size="15" value="" />
</p>

<p>College:
<input type="varchar" name="college" size="20" value="" />
</p>

<p>
<input type="submit" name="submit" value="Send" />
</p>

</form>




</body>

</html>
